<?php
namespace Users\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Users\Form\RegisterForm;

class RegisterController extends AbstractActionController{
	public function indexAction(){
		$form = new RegisterForm();
		$view = new ViewModel(array('form'=>$form));
		return $view;
	}
	public function confirmAction(){
		$view = new ViewModel();
		return $view;
	}
}
?>